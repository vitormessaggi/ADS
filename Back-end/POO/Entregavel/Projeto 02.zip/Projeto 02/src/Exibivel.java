
public interface Exibivel {
    void exibir();
}